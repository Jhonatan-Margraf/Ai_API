const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors'); // Importe o middleware cors
const { GoogleGenerativeAI } = require("@google/generative-ai");

const app = express();
const port = 3000;

const apiKey = 'AIzaSyCKE9Mq0SiUxY6U9bTQ2ZbcRKLiFqe_Wdk'; // Substitua pela sua chave de API
const genAI = new GoogleGenerativeAI(apiKey);

const model = genAI.getGenerativeModel({
    model: "gemini-1.5-flash",
});

const generationConfig = {
    temperature: 1,
    topP: 0.95,
    topK: 64,
    maxOutputTokens: 8192,
    responseMimeType: "text/plain",
};

// Configurando o CORS para permitir requisições de qualquer origem
app.use(cors()); 

// Configurando o body-parser para analisar JSON
app.use(bodyParser.json());

// Rota para lidar com as mensagens do chatbot
app.post('/api/chat', async (req, res) => {
    const userMessage = req.body.message;

    console.log("Requisição em back:" + userMessage);

    const chatSession = model.startChat({
        generationConfig,
        history: [
            {
                role: "user",
                parts: [
                    { text: userMessage },
                ],
            }
        ],
    });

    try {
        const result = await chatSession.sendMessage(userMessage);
        res.json({ response: result.response.text });
    } catch (error) {
        console.error("Erro na API do Gemini:", error);
        res.status(500).json({ error: "Ocorreu um erro ao processar sua solicitação." });
    }
});

// Inicia o servidor
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${3000}`);
});