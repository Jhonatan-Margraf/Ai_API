document.getElementById('send-button').addEventListener('click', async () => {
   alert("chegou")
  const inputElement = document.getElementById('chat-input');
  const message = inputElement.value;
  if (message.trim() === '') return;

  // Adiciona a mensagem do usuário ao chat
  const userMessageElement = document.createElement('div');
  userMessageElement.className = 'message user-message';
  userMessageElement.textContent = message;
  document.getElementById('chat-box').appendChild(userMessageElement);
  inputElement.value = '';

  // Envia a mensagem para o back-end (API de IA)
  const response = await fetch('http://127.0.0.1:3000/api/chat', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message })
  });

  const data = await response.json();

  console.log(data)

//  console.log(JSON.stringify(data));
  
/*if (data && data.response) {*/
  const aiMessage = data.response.text();

  // Adiciona a resposta da IA ao chat
  const aiMessageElement = document.createElement('div');
  aiMessageElement.className = 'message ai-message';
  aiMessageElement.textContent = aiMessage;
  document.getElementById('chat-box').appendChild(aiMessageElement);

  // Role para a última mensagem
  document.getElementById('chat-box').scrollTop = document.getElementById('chat-box').scrollHeight;
/*} else {
    alert("Não retornou resposta!");
}*/
  
});

/*async function minha_funcao1 () {
  

  alert("chegou")
 const inputElement = document.getElementById('chat-input');
 const message = inputElement.value;
 if (message.trim() === '') return;

 // Adiciona a mensagem do usuário ao chat
 const userMessageElement = document.createElement('div');
 userMessageElement.className = 'message user-message';
 userMessageElement.textContent = message;
 document.getElementById('chat-box').appendChild(userMessageElement);
 inputElement.value = '';

 // Envia a mensagem para o back-end (API de IA)
 const response = await fetch('/api/chat', {
     method: 'POST',
     headers: {
         'Content-Type': 'application/json'
     },
     body: JSON.stringify({ message })
 });

 const data = await response.json();
 const aiMessage = data.response.text();

 // Adiciona a resposta da IA ao chat
 const aiMessageElement = document.createElement('div');
 aiMessageElement.className = 'message ai-message';
 aiMessageElement.textContent = aiMessage;
 document.getElementById('chat-box').appendChild(aiMessageElement);

 // Role para a última mensagem
 document.getElementById('chat-box').scrollTop = document.getElementById('chat-box').scrollHeight;
}*/
